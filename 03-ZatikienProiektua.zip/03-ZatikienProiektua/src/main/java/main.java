
/**
 *
 * @author mochales.julen
 */
public class main {

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        // TODO code application logic here

        System.out.println("A: " + 40 / 10);
        System.out.println("B: " + 4 / 0);

        Zatikia z1;
        z1 = new Zatikia(5, 11);
        Zatikia z2;
        z2 = new Zatikia(2 / 11);

        System.out.println(Zatikia.batu(z1, z2));
        z1.batu(z2);
        System.out.println(z1);
    }
}
