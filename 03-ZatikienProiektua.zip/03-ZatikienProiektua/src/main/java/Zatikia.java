/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author mochales.julen
 */
class Zatikia {

    private int zenbakitzailea, izendatzailea;
s 
   public Zatikia(int zenbakitzailea, int izendatzailea) {
        this.zenbakitzailea = zenbakitzailea;
        this.izendatzailea = izendatzailea;
    }

    public Zatikia() {
    }

    public void setIzendatzailea(int izendatzailea) {
        this.izendatzailea = izendatzailea;
    }

    public void setZenbakitzailea(int zenbakitzailea) {
        this.zenbakitzailea = zenbakitzailea;
    }

    public int getIzendatzailea() {
        return izendatzailea;
    }

    public int getZenbakitzailea() {
        return zenbakitzailea;
    }

    @Override
   

    public Zatikia biderkatu(Zatikia zat1, Zatikia zat2) {
        Zatikia zat3 = new Zatikia();

        zat3.setZenbakitzailea(zat1.getZenbakitzailea() * zat2.getZenbakitzailea());
        zat3.setIzendatzailea(zat1.getIzendatzailea() * zat2.getIzendatzailea());
        return zat3;

    }

    public Zatikia batu(Zatikia zat1, Zatikia zat2) {
        Zatikia zat3 = new Zatikia();

        int mcd = 0;
        int a = Math.max(zat1.getIzendatzailea(), zat2.getIzendatzailea());
        int b = Math.min(zat1.getIzendatzailea(), zat2.getIzendatzailea());
        do {
            mcd = b;
            b = a % b;
            a = mcd;
        } while (b != 0);

        int mcm = 0;
        int c = Math.max(zat1.getIzendatzailea(), zat2.getIzendatzailea());
        int d = Math.min(zat1.getIzendatzailea(), zat2.getIzendatzailea());
        mcm = (c / mcd) * d;
        int zat4 = (mcm / zat1.getIzendatzailea()) * zat1.getZenbakitzailea();
        int zat5 = (mcm / zat2.getIzendatzailea()) * zat2.getZenbakitzailea();
        zat3.setZenbakitzailea(zat4 + zat5);
        zat3.setIzendatzailea(mcm);
        return zat3;

    }

    public void batu(Zatikia besteZatBat) {
        Zatikia zat1 = new Zatikia(zenbakitzailea, izendatzailea);

        Zatikia.batu(besteZatBat, zat1);

    }

}
